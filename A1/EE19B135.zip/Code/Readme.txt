I have additionally performed EVD and SVD to an rgb image along with the gray scale("11.jpg") image provided.
The rgb image is called "color.jpg" and is present in the same folder.Kindly make sure to keep this image in the
same directory/folder as the .py file for proper execution of my code.
Thank you